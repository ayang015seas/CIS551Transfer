import sys
sys.stdout.buffer.write(b"ayang015 \0")
sys.stdout.buffer.write(b"CIS551")

